import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-main-view',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './main-view.component.html',
})
export class MainViewComponent {



}
