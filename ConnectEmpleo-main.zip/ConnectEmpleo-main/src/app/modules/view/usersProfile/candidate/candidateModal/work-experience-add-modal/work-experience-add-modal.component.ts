import { Component } from '@angular/core';

@Component({
  selector: 'app-work-experience-add-modal',
  standalone: true,
  imports: [],
  templateUrl: './work-experience-add-modal.component.html',
  styleUrl: './work-experience-add-modal.component.css'
})
export class WorkExperienceAddModalComponent {

}
