import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-users-view',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './users-view.component.html',
})
export class UsersViewComponent {

}
