import { Component } from '@angular/core';

@Component({
  selector: 'app-recruiter',
  standalone: true,
  imports: [],
  templateUrl: './recruiter.component.html',
  styleUrl: './recruiter.component.css'
})
export class RecruiterComponent {

}
